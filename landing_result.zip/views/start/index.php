<?php
require_once './controllers/controller.php';

$controller = new StartController;

require_once './views/selectedaction.php';
?>
