<?php
//db
$db_host='127.0.0.1';
$db_user='root';
$db_password='';
$db_name='landing';
?>
